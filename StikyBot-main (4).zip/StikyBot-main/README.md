This file guides setuo,usage, and troubleshooting.Refer for instructions and tips.
